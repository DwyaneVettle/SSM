package com.sccs.spring;

public class Student {
    private String sName;
    private int sId;
    private String sSex;

    public void setsName(String sName) {
        this.sName = sName;
    }

    public void setsId(int sId) {
        this.sId = sId;
    }

    public void setsSex(String sSex) {
        this.sSex = sSex;
    }

    public String getsName() {
        return sName;
    }

    public int getsId() {
        return sId;
    }

    public String getsSex() {
        return sSex;
    }
    public void add(){ }
}
