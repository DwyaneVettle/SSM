package zuoye;

public class StudentTest {
    public static void main(String[] args) {
        Student s1 = new Student("201820221","xiaoqi",'女',"物联网","河北");
        System.out.println(s1.toString());

        Student s2 = new Student("201820222","xiaowen",'女',"物联网","河北");
        System.out.println(s2.toString());

        Student s3 = new Student("201820221","xiaowen",'女',"物联网","河北");
        System.out.println(s3.toString());

        if (s1.equals(s3)) {
            System.out.println("学号相同的是同一个对象");
        }else {
            System.out.println("学号相同的不是同一个对象");
        }
    }
}
