package zuoye;

public class Spring {
    public class MyFactory {
        private Properties properties = new Properties();

        public MyFactory() {
        }

        public  MyFactory(String conf) throws IOException {
//        加载配置文件
            properties.load(MyFactory.class.getResourceAsStream(conf));
        }

        //    获取对象
        public Object getBean(String beanName) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
//        获取类路径
            String property = properties.getProperty(beanName);
            if (property != null){
                Class claz = null;
//            反射：加载类对象
                claz = Class.forName(property);
//            反射：获取对象
                return claz.newInstance();
            }
            return null;
        }
    }
}
