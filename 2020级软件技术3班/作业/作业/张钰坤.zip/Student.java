package zuoye;

public class Student {

        private String number;
        private String name;
        private char sex;
        private String specialty;
        private String address;

        public Student() {
            super();
            // TODO Auto-generated constructor stub
        }

        public Student(String number, String name, char sex, String specialty, String address) {
            super();
            this.number = number;
            this.name = name;
            this.sex = sex;
            this.specialty = specialty;
            this.address = address;
        }

        public String getNumber() {
            return number;
        }

        public void setNumber(String number) {
            this.number = number;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public char getSex() {
            return sex;
        }

        public void setSex(char sex) {
            this.sex = sex;
        }

        public String getSpecialty() {
            return specialty;
        }

        public void setSpecialty(String specialty) {
            this.specialty = specialty;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String toString() {
            return "number=" + number + ", name=" + name + ", sex=" + sex + ", specialty=" + specialty
                    + ", address=" + address;
        }

        public boolean equals(Student s) {
            if (this.number.equals(s.number)) {
                return true;
            }else {
                return false;
            }
        }

    }


