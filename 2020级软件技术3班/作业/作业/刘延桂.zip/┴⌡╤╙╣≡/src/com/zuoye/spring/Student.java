package com.zuoye.spring;
//1.创建Student类，方法：test方法里输出，属性：sName,sId,sSex完成Spring注入，并测试
public class Student {

    private String Name;
    private String Id;
    private String Sex;

    public String getName() {
        return Name;
    }
    public void setName(String Name) { this.Name = Name; }

    public String getId() {
        return Id;
    }
    public void setId(String Id) {
        this.Id = Id;
    }

    public String getSex() {
        return Sex;
    }
    public void setSex(String Sex) { this.Sex = Sex; }


}
