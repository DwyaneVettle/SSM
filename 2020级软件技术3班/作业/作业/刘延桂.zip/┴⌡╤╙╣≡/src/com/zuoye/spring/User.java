package com.zuoye.spring;
// 用构造方法和p命名空间，实现属性注入
public class User {
    private String uName;
    private String uId;
    private String uSex;

    public String getName() {
        return uName;
    }

    public void setuuName(String Name) {this.uName = uName;}

    public String getuId() {
        return uId;
    }

    public void setuuId(String uId) {
        this.uId = uId;
    }

    public String getuSex() {
        return uSex;
    }

    public void setuSex(String Sex) {
        this.uSex = uSex;
    }


    public void setuName(String uName) {

    }

    public void setuId(String uId) {
    }

    public void setName(String name) {
    }


}
