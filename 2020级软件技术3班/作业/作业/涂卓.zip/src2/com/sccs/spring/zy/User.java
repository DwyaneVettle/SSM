package com.sccs.spring.zy;

public class User {
    public void add(){System.out.println("执行成功");};
}
