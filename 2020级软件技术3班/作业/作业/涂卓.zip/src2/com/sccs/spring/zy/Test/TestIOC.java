package com.sccs.spring.zy.Test;

import com.sccs.spring.zy.Ka;
import com.sccs.spring.zy.Ka2;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestIOC {
@Test
    public void test1(){
        //1.加载xml文件
        ClassPathXmlApplicationContext contest = new ClassPathXmlApplicationContext("spring_config.xml");
        //2.加载对象
        Ka ka = contest.getBean("Ka",Ka.class);
        System.out.println("驾驭连接未知世界的疾风");
        ka.testKa();
    }
    @Test
    public void Test2() {

        ClassPathXmlApplicationContext contest = new ClassPathXmlApplicationContext("spring_config.xml");

        Ka2 ka2 = contest.getBean("ka2", Ka2.class);
        System.out.println(ka2);
        //System.out.println(ka2.getGuo());
        //System.out.println(ka2.getZiduan());
        ka2.test();
    }
}
