package com.sccs.spring.zy;

public class Ka2 {
    private String guo;
    private String ziduan;

    public String getGuo() {
        return guo;
    }

    public void setGuo(String guo) {
        this.guo = guo;
    }

    public String getZiduan() {
        return ziduan;
    }

    public void setZiduan(String ziduan) {
        this.ziduan = ziduan;
    }
    public void test(){
        System.out.println(guo+"巫妖"+ziduan);
    }
}
