package com.sccs.spring.zy;

public class Ka {
    private String kaname;
    private String zi;
    // 生成有参构造


    public Ka(String kaname, String zi) {
        this.kaname = kaname;
        this.zi = zi;
    }
    public void testKa(){
        System.out.println(kaname+":"+zi);
    }
}
