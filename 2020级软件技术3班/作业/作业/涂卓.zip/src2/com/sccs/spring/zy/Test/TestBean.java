package com.sccs.spring.zy.Test;

public class TestBean {
}
