package com.qwe;

import com.qwe.Employee;
import com.qwe.Student;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

    @Test
    public void test01(){
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Student student = context.getBean(Student.class);
        Employee employee = context.getBean(Employee.class);

        // 学生
        System.out.println(student.getName());
        System.out.println(student.getSex());
        student.test();

        //员工
        System.out.println(employee.getName());
        System.out.println(employee.getNationality());
        System.out.println(employee.getAge());
        employee.test();


    }
}
