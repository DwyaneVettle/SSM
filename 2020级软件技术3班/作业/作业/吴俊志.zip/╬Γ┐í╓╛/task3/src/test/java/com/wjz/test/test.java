package com.lg.test;

import com.wjz.Emp;
import com.wjz.Student;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

    @Test
    public void test(){
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Student student = context.getBean(Student.class);
        Emp employee = context.getBean(Emp.class);

        // 学生
        System.out.println(student.getName());
        System.out.println(student.getSex());
        student.test();

        //员工
        System.out.println(employee.getName());
        System.out.println(employee.getAddress());
        System.out.println(employee.getJoinTime());
        emp.test();


    }
}
