package com.sccs.spring.test;

import com.sccs.spring.Emp;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmp {
    @Test
    public void test02(){
        ApplicationContext emo = new ClassPathXmlApplicationContext("spring_config.xml");
        Emp xiao = emo.getBean("emo",Emp.class);
        System.out.println(xiao);
        System.out.println(xiao.getuName());
        System.out.println(xiao.getPwd());
        System.out.println(xiao.getAge());
        System.out.println(xiao.getHobby());
    }
}
