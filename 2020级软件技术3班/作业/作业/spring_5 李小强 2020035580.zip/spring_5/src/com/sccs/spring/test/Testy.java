package com.sccs.spring.test;

import com.sccs.spring.Student;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Testy {
    @Test
    public void test(){
        ApplicationContext work = new ClassPathXmlApplicationContext("spring_config.xml");
        Student stu = work.getBean("stu",Student.class);
        System.out.println(stu);
        System.out.println(stu.getsName());
        System.out.println(stu.getsId());
        System.out.println(stu.getsSex());
    }
}
