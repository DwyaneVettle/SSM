package com.ckh.test;

import com.lg.pojo.Employee;
import com.lg.pojo.Student;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

    @Test
    public void test01(){
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Student student = context.getBean(Student.class);
        Employee employee = context.getBean(Employee.class);

        // 学生
        System.out.println(student.getName());
        System.out.println(student.getSex());
        student.test();

        //员工
        System.out.println(employee.getName());
        System.out.println(employee.getAddress());
        System.out.println(employee.getJoinTime());
        employee.test();


    }
}
