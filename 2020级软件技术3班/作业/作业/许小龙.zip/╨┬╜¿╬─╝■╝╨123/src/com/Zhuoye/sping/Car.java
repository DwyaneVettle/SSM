package com.Zhuoye.sping;

public class Car {
    private  String XingHao;
    private  String Color;
    private String  Chexing;


    public Car(String xingHao, String color, String chexing) {
        XingHao = xingHao;
        Color = color;
        Chexing = chexing;
    }

    public String getXingHao() {
        return XingHao;
    }

    public String getColor() {
        return Color;
    }

    public String getChexing() {
        return Chexing;
    }
}
