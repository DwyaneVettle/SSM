package com.zfg.test;

import com.zfg.pojo.Employee;
import com.zfg.pojo.Student;
import com.zfg.pojo.User;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HomeworkTest {
    @Test
    public void test01(){
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        Student student = context.getBean(Student.class);
        Employee employee = context.getBean(Employee.class);
        User user01 = context.getBean("user01",User.class);
        User user02 = context.getBean("user02", User.class);
        User user03 = context.getBean("user03", User.class);

        student.test();// 调用student的test()方法
        System.out.println(student.getName());// 获取student的name
        System.out.println(student);// toString方法

        System.out.println("\n====================================\n");

        employee.work();// 调用employee的work()方法
        System.out.println(employee.getName());// 获取employee的name
        System.out.println(employee);// toString方法

        System.out.println("\n====================================\n");

        System.out.println(user01);// 测试user01--p命名空间
        System.out.println(user02);// 测试user02--构造函数赋值
        System.out.println(user03);// 测试user03--c命名空间

    }
}
