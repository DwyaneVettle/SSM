package com.demo.spring.test;

import com.demo.spring.Emp;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmp {

    @Test
    public void empTest(){
//        加载xml文件
        ApplicationContext context = new ClassPathXmlApplicationContext("spring_config.xml");
//         2.加载对象
        Emp emp =context.getBean("emp", Emp.class);
        System.out.println(emp);
        System.out.println(emp.getName());
        System.out.println(emp.getAge());
        System.out.println(emp.getAddr());
    }
}
