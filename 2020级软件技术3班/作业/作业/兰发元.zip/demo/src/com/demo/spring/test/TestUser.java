package com.demo.spring.test;

import com.demo.spring.User;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestUser {
    @Test
    public void test(){
        //        加载xml
        ApplicationContext context = new ClassPathXmlApplicationContext("spring_config.xml");
        //        加载对象
        User user = context.getBean("user", User.class);
        System.out.println(user);
        System.out.println(user.getName());
        System.out.println(user.getAge());
        System.out.println(user.getSex());
    }
}
