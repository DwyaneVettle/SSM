package com.demo.spring;

public class Student {

//    1.创建Student类，方法：test方法里输出，属性：sName,sId,sSex完成Spring注入，并测试

    private String sName;
    private Integer sId;
    private String sSex;

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName;
    }

    public Integer getsId() {
        return sId;
    }

    public void setsId(Integer sId) {
        this.sId = sId;
    }

    public String getsSex() {
        return sSex;
    }

    public void setsSex(String sSex) {
        this.sSex = sSex;
    }
}
