package com.cmh.pojo;

public class Order {
    private String oname;
    private String oaddr;

    public Order(String oname, String oaddr) {
        this.oname = oname;
        this.oaddr = oaddr;
    }
    public void test(){
        System.out.println("test()方法执行。。");
    }

    public String getOadder() {
        return oname;
    }

    public void setOname(String oname) {
        this.oname = oname;
    }

    public void setOaddr(String oaddr) {
        this.oaddr = oaddr;
    }
}
