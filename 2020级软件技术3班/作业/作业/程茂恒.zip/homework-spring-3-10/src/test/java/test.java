import com.cmh.pojo.Emp;
import com.cmh.pojo.Order;
import com.cmh.pojo.Student;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {
    @Test
    public void test01(){
        ApplicationContext context = new ClassPathXmlApplicationContext("Spring-config.xml");
        Student student = context.getBean("student",Student.class);
        System.out.println(student);
        student.test();
    }

    @Test
    public void test02(){
        ApplicationContext context = new ClassPathXmlApplicationContext("Spring-config.xml");
        Emp student = context.getBean("emp", Emp.class);
        Emp emp2 = context.getBean("emp2", Emp.class);
        System.out.println(emp2);
        System.out.println(student);
        student.test();
    }
    @Test
    public void test03(){
       ApplicationContext context = new ClassPathXmlApplicationContext("Spring-config.xml");
        Order order = context.getBean("order", Order.class);
        System.out.println(order);
        System.out.println(order.getOadder());
        order.test();
    }
}
