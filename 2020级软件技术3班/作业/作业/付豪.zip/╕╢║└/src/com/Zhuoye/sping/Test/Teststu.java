package com.Zhuoye.sping.Test;



import com.Zhuoye.sping.Car;
import com.Zhuoye.sping.Emp;
import com.Zhuoye.sping.Student;
import com.Zhuoye.sping.dianlao;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Teststu {


    @Test
    public void teststu01(){
        //加载xml文件
        ApplicationContext Context = new ClassPathXmlApplicationContext("sping_student.xml");

        final Student student = Context.getBean("student", Student.class);
        System.out.println(student);
        System.out.println(student.getsName());
        System.out.println(student.getSid());
        System.out.println(student.getsSex());
    }
    @Test
    public void testsEop(){
        ApplicationContext Context = new ClassPathXmlApplicationContext("sping_student.xml");

        final Emp emp = Context.getBean("emp", Emp.class);
        System.out.println(emp);
        System.out.println(emp.geteName());
        System.out.println(emp.getPingpai());
        System.out.println(emp.getClolr());
    }
    @Test
    public void  testcar(){
        ApplicationContext Context = new ClassPathXmlApplicationContext("sping_student.xml");
        Car car = Context.getBean("car", Car.class);
        System.out.println(car);
        System.out.println(car.getXingHao());
        System.out.println(car.getColor());
        System.out.println(car.getXingHao());
    }
    @Test
    public void  testdi() {
        ApplicationContext Context = new ClassPathXmlApplicationContext("sping_student.xml");
        dianlao dianlao = Context.getBean("dianlao", dianlao.class);
        System.out.println(dianlao);
        System.out.println(dianlao.getX());
        System.out.println(dianlao.getY());
    }
}
