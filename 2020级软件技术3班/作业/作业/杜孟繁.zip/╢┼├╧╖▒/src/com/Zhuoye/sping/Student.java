package com.Zhuoye.sping;

public class Student {
   private String sName;
   private int sid ;
   private  String sSex;

    public String getsName() { return sName; }

    public void setsName(String sName) { this.sName = sName; }

    public int getSid() { return sid; }

    public void setSid(int sid) { this.sid = sid; }

    public String getsSex() { return sSex; }

    public void setsSex(String sSex) { this.sSex = sSex; }
}
