package com.Zhuoye.sping;

public class Emp {
    private String eName;
    private String Pingpai;
    private  String  clolr;

    public String geteName() {
        return eName;
    }

    public void seteName(String eName) {
        this.eName = eName;
    }

    public String getPingpai() {
        return Pingpai;
    }

    public void setPingpai(String pingpai) {
        Pingpai = pingpai;
    }

    public String getClolr() {
        return clolr;
    }

    public void setClolr(String clolr) {
        this.clolr = clolr;
    }
}
