package com.Zhuoye.sping;

public class dianlao {
     private String X;
     private  String Y;

    public String getX() {
        return X;
    }

    public void setX(String x) {
        X = x;
    }

    public String getY() {
        return Y;
    }

    public void setY(String y) {
        Y = y;
    }
}
