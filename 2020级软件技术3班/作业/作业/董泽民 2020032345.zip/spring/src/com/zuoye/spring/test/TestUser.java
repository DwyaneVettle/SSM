package com.zuoye.spring.test;


import com.zuoye.spring.User;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestUser {

    @Test
    public void test01() {
        ApplicationContext context = new ClassPathXmlApplicationContext("spring_config.xml");

        User user = context.getBean("user", User.class);
        System.out.println(user);
        System.out.println(user.getuName());
        System.out.println(user.getuId());
        System.out.println(user.getuSex());
    }
}
