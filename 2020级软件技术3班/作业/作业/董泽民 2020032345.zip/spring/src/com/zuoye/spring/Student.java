package com.zuoye.spring;
//1.创建Student类，方法：test方法里输出，属性：sName,sId,sSex完成Spring注入，并测试
public class Student {

    private String sName;
    private String sId;
    private String sSex;

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public String getsSex() {
        return sSex;
    }

    public void setsSex(String sSex) {
        this.sSex = sSex;
    }
}
