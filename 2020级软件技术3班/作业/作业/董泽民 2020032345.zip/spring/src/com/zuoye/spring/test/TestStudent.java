package com.zuoye.spring.test;


import com.zuoye.spring.Student;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestStudent {

    @Test
    public void test01() {
        // 1.加载xml文件
        ApplicationContext context = new ClassPathXmlApplicationContext("spring_config.xml");
        // 2.加载对象
        Student student = context.getBean("student", Student.class);
        System.out.println(student);
        System.out.println(student.getsName());
        System.out.println(student.getsId());
        System.out.println(student.getsSex());

    }
}
