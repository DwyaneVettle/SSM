package com.zuoye.spring;
//2.创建Emp类，方法，属性至少3个，实现Spring注入，完成测试
public class Emp {
    private String zName;
    private String zAge;
    private String zSex;
    private String zAddr;
    private String zHobby;

    public String getzName() {
        return zName;
    }

    public void setzName(String zName) {
        this.zName = zName;
    }

    public String getzAge() {
        return zAge;
    }

    public void setzAge(String zAge) {
        this.zAge = zAge;
    }

    public String getzSex() {
        return zSex;
    }

    public void setzSex(String zSex) {
        this.zSex = zSex;
    }

    public String getzAddr() {
        return zAddr;
    }

    public void setzAddr(String zAddr) {
        this.zAddr = zAddr;
    }

    public String getzHobby() {
        return zHobby;
    }

    public void setzHobby(String zHobby) {
        this.zHobby = zHobby;
    }
}
